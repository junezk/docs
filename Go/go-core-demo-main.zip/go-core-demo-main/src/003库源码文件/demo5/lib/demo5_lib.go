package lib

import "fmt"

func Hello(name string) {
	fmt.Printf("Hello, %s!\n", name)
}
