package main

import "fmt"

func hello(name string) {
	fmt.Printf("Hello, %s!\n", name)
}
