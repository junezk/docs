# golang-unit-test-demo
some code snippet about golang unit test 

[Go语言单元测试图文教程](https://www.liwenzhou.com/)中的单元测试示例代码。
