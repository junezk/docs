---
root: true
name: Демо
sort: 8
---

# Демки
В этом разделе мы покажем некоторые демо, которые помогут вам в изучении Beego.

## Чат
Вы можете использовать BeeGo и WebSocket для создания чата:

[Посмотреть код на GitHub](https://github.com/beego/samples/tree/master/WebIM)

## API сервиса сокращателя ссылок
Эта демка поможет вам понять, как разработать высокопроизводительное API на BeeGo:

[Посмотреть код на GitHub](https://github.com/beego/samples/tree/master/shorturl)

## Список ToDo
ToDo список показывает, как разрабатывается типичное Web приложение на BeeGo:

[Посмотреть код на GitHub](https://github.com/beego/samples/tree/master/todo)
