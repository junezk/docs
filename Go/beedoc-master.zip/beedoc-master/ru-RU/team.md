# Команда разработчиков

### AstaXie

- Роль в команде: основатель BeeGo, главный разработчик.
- Социальная сеть: [Sina Weibo](http://weibo.com/533452688) [GitHub](https://github.com/astaxie) [Twitter](https://twitter.com/astaxie) [Google+](https://plus.google.com/u/0/111292884696033638814)

### Slene

- Роль в команде: ответственный за ORM, разработчик демо приложений для BeeGo и официального сайта.
- Социальная сеть: [Sina Weibo](http://weibo.com/slene) [GitHub](https://github.com/slene) [Twitter](https://twitter.com/slene)


### ClownFish

- Роль в команде: ответственный за BeeGo admin management system.
- Социальная сеть: [GitHub](https://github.com/osgochina)

### Lei Cao

- Роль в команде: Главный разработчки английской документации и ресурсов.
- Социальная сеть: [GitHub](https://github.com/lei-cao)
