# 开发团队

### Asta谢

- 团队角色：beego 创始人，框架主要开发者。
- 社交网络：[新浪微博](http://weibo.com/533452688) [GitHub](https://github.com/astaxie) [Twitter](https://twitter.com/astaxie) [Google+](https://plus.google.com/u/0/111292884696033638814)

### Ming Deng

- 团队角色：beego v2 主要维护者
- [GitHub](https://github.com/flycash)

### Slene

- 团队角色：ORM 开发者，兼职 beego 示例及官网开发
- 社交网络：[新浪微博](http://weibo.com/slene) [GitHub](https://github.com/slene) [Twitter](https://twitter.com/slene)


### ClownFish

- 团队角色：beego 后台管理系统开发者
- 社交网络：[GitHub](https://github.com/osgochina)

### Lei Cao

- 团队角色：维护英文文档和资源
- 社交网络：[GitHub](https://github.com/lei-cao)
