---
name: session 模块
sort: 1
---

# 特别注意

*这个文档是 session 独立模块，即你单独拿这个模块应用于其他应用中，如果你想在 beego 中使用 session，请查看文档[session 控制](/zh-CN/mvc/controller/session.md)*

例子参考[beego-example](https://github.com/beego/beego-example)下的`session`部分

# session 介绍

session 模块是用来存储客户端用户，session 模块目前只支持 cookie 方式的请求，如果客户端不支持 cookie，那么就无法使用该模块。

session 模块参考了 `database/sql` 的引擎写法，采用了一个接口，多个实现的方式。目前实现了 memory、file、Redis 和 MySQL 四种存储引擎。

通过下面的方式安装 session：

	go get github.com/beego/beego/v2/server/web/session

# session 使用

首先你必须导入包：

```go
import (
	"github.com/beego/beego/v2/server/web/session"
)
```

然后你初始化一个全局的变量用来存储 session 控制器：

	var globalSessions *session.Manager

接着在你的入口函数中初始化数据：

```go
func init() {
	sessionConfig := &session.ManagerConfig{
	CookieName:"gosessionid", 
	EnableSetCookie: true, 
	Gclifetime:3600,
	Maxlifetime: 3600, 
	Secure: false,
	CookieLifeTime: 3600,
	ProviderConfig: "./tmp",
	}
	globalSessions, _ = session.NewManager("memory",sessionConfig)
	go globalSessions.GC()
}
```

NewManager 函数的参数的函数如下所示

1. 引擎名字，可以是 memory、file、mysql 或 redis。
2. 一个 JSON 字符串,传入 Manager 的配置信息
	* cookieName: 客户端存储 cookie 的名字。
	* enableSetCookie,omitempty: 是否开启 SetCookie,omitempty 这个设置
	* gclifetime: 触发 GC 的时间。
	* maxLifetime: 服务器端存储的数据的过期时间
	* secure: 是否开启 HTTPS，在 cookie 设置的时候有 cookie.Secure 设置。
	* sessionIDHashFunc: sessionID 生产的函数，默认是 sha1 算法。
	* sessionIDHashKey: hash 算法中的 key。
	* cookieLifeTime: 客户端存储的 cookie 的时间，默认值是 0，即浏览器生命周期。
	* providerConfig: 配置信息，根据不同的引擎设置不同的配置信息，详细的配置请看下面的引擎设置

最后我们的业务逻辑处理函数中可以这样调用：

```go
func login(w http.ResponseWriter, r *http.Request) {
	sess, _ := globalSessions.SessionStart(w, r)
	defer sess.SessionRelease(w)
	username := sess.Get("username")
	if r.Method == "GET" {
		t, _ := template.ParseFiles("login.gtpl")
		t.Execute(w, nil)
	} else {
		sess.Set("username", r.Form["username"])
	}
}
```

globalSessions 有多个函数如下所示：

- SessionStart 根据当前请求返回 session 对象
- SessionDestroy 销毁当前 session 对象
- SessionRegenerateId 重新生成 sessionID
- GetActiveSession 获取当前活跃的 session 用户
- SetHashFunc 设置 sessionID 生成的函数
- SetSecure 设置是否开启 cookie 的 Secure 设置

返回的 session 对象是一个 Interface，包含下面的方法

* Set(key, value interface{}) error
* Get(key interface{}) interface{}
* Delete(key interface{}) error
* SessionID() string
* SessionRelease()
* Flush() error

# 引擎设置

上面已经展示了 memory 的设置，接下来我们看一下其他三种引擎的设置方式：

- mysql

	其他参数一样，只是第四个参数配置设置如下所示，详细的配置请参考 [mysql](https://github.com/go-sql-driver/mysql#dsn-data-source-name)：

		username:password@protocol(address)/dbname?param=value

- redis

	配置文件信息如下所示，表示链接的地址，连接池，访问密码，没有保持为空：
	> 注意：若使用redis等引擎作为session backend，请在使用前导入 < _ "github.com/beego/beego/v2/server/web/session/redis" >
	        否则会在运行时发生错误，使用其他引擎时也是同理。
	        
		127.0.0.1:6379,100,astaxie

- file

	配置文件如下所示，表示需要保存的目录，默认是两级目录新建文件，例如 sessionID 是 `xsnkjklkjjkh27hjh78908`，那么目录文件应该是 `./tmp/x/s/xsnkjklkjjkh27hjh78908`：

		./tmp

# 如何创建自己的引擎

在开发应用中，你可能需要实现自己的 session 引擎，beego 的这个 session 模块设计的时候就是采用了 interface，所以你可以根据接口实现任意的引擎，例如 memcache 的引擎。

```go
// Store contains all data for one session process with specific id.
type Store interface {
	Set(ctx context.Context, key, value interface{}) error     //set session value
	Get(ctx context.Context, key interface{}) interface{}      //get session value
	Delete(ctx context.Context, key interface{}) error         //delete session value
	SessionID(ctx context.Context) string                      //back current sessionID
	SessionRelease(ctx context.Context, w http.ResponseWriter) // release the resource & save data to provider & return the data
	Flush(ctx context.Context) error                           //delete all data
}

// Provider contains global session methods and saved SessionStores.
// it can operate a SessionStore by its id.
type Provider interface {
	SessionInit(ctx context.Context, gclifetime int64, config string) error
	SessionRead(ctx context.Context, sid string) (Store, error)
	SessionExist(ctx context.Context, sid string) (bool, error)
	SessionRegenerate(ctx context.Context, oldsid, sid string) (Store, error)
	SessionDestroy(ctx context.Context, sid string) error
	SessionAll(ctx context.Context) int // get all active session
	SessionGC(ctx context.Context)
}
```

最后需要注册自己写的引擎：

```go
func init() {
	Register("own", ownadaper)
}
```
