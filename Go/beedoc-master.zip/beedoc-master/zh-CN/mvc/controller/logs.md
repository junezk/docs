---
name: Logging
sort: 11
---

# Logging

旧式的直接使用`beego.XXXX`的方法已经被移除了，请使用[logs module](/zh-CN/module/logs.md)
