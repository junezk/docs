# 视频教程

这是课程的详细规划:
https://github.com/beego/tutorial/blob/master/README_zh.md

1. beego 入门教程第一课之设计思路

	<iframe src="http://www.tudou.com/programs/view/html5embed.action?type=0&code=EliSnrCpCi4&lcode=&resourceId=375194595_06_05_99" allowtransparency="true" scrolling="no" border="0" frameborder="0" style="width:480px;height:400px;"></iframe>

	slide地址: [设计思路](http://go-talks.appspot.com/github.com/beego/tutorial/zh/1/why_beego.slide#1)
	* 土豆: http://www.tudou.com/programs/view/EliSnrCpCi4/
	* 优酷: http://v.youku.com/v_show/id_XNzEwMTczNzY4.html
	* 网盘下载地址: http://pan.baidu.com/s/1pJO7btD

2. beego 入门教程第二课之路由设置

	<iframe src="http://www.tudou.com/programs/view/html5embed.action?type=0&code=mid55HCg1EY&lcode=&resourceId=375194595_06_05_99" allowtransparency="true" scrolling="no" border="0" frameborder="0" style="width:480px;height:400px;"></iframe>

	slide 地址: [路由设置](http://go-talks.appspot.com/github.com/beego/tutorial/zh/2/router.slide#1)
	* 土豆：http://www.tudou.com/programs/view/mid55HCg1EY/
	* 51CTO: http://edu.51cto.com/lesson/id-24586.html
	* 网盘：http://pan.baidu.com/s/1o6jXSc6

3. beego 入门教程第三课之参数设置

	<iframe src="http://www.tudou.com/programs/view/html5embed.action?type=0&code=U1MiDKq4JdQ&lcode=&resourceId=375194595_06_05_99" allowtransparency="true" scrolling="no" border="0" frameborder="0" style="width:480px;height:400px;"></iframe>

	slide 地址: [参数设置](http://go-talks.appspot.com/github.com/beego/tutorial/zh/3/params.slide#1)
	* 土豆：http://www.tudou.com/programs/view/U1MiDKq4JdQ/
	* 51CTO: http://edu.51cto.com/lesson/id-24586.html
	* 网盘：http://pan.baidu.com/s/1i32zA41

4. beego 一分钟创建 API

	<iframe src="http://www.tudou.com/programs/view/html5embed.action?type=0&code=aM7iKLlBlrU&lcode=&resourceId=375194595_06_05_99" allowtransparency="true" scrolling="no" border="0" frameborder="0" style="width:480px;height:400px;"></iframe>

	* 网盘下载链接: http://pan.baidu.com/s/1sj0jI6T 密码: x46e
