---
name: URL Shortener
sort: 2
---

# URL Kısaltıcı API servisi

Bu basit örnek Beego tabanlı bir API uygulamasıdır. İçerisinde iki API endpointe sahiptir :

/v1/shorten
/v1/expand

[Kodu GitHub'ta Görüntüle](https://github.com/beego/samples/tree/master/shorturl)
