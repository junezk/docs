# Donate to Beego

<h4>
	<b><font color="red">
    <p>Beego framework dedicates to providing a fast way to develop web applications and advocating for Go language. Your supports are highly appreciated and it means a lot to us.</p>
    <p>Our Beego core team has been working a lot and improving Beego for more than a year. We dedicated a lot to provide everyone a better framework. If you feel Beego is helpful for you and want to kindly support it, we appreciate that. ^_^</p>
	</font></b>
</h4>

<h4>
	<b>Donate by Paypal:</b>
	<p>
		<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="MR3MV8ZX9BWJ2">
<table>
<tr><td><input type="hidden" name="on0" value="support Beego">support Beego</td></tr><tr><td><select name="os0">
	<option value="Option 1">Option 1 $10.00 USD</option>
	<option value="Option 2">Option 2 $20.00 USD</option>
	<option value="Option 3">Option 3 $50.00 USD</option>
	<option value="Option 4">Option 4 $100.00 USD</option>
	<option value="Option 5">Option 5 $200.00 USD</option>
	<option value="Option 6">Option 6 $500.00 USD</option>
	<option value="Option 7">Option 7 $1,000.00 USD</option>
</select> </td></tr>
</table>
<input type="hidden" name="currency_code" value="USD">
<input type="image" src="https://www.paypalobjects.com/en_US/C2/i/btn/btn_buynowCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>
	</p>
</h4>

### Your donation will be used as:

- Supports the development of Beego
- Supports maintaining the communities
- Upgrade to better server
- Award the outstanding contributors
- Holds community activities and lectures

### Donation Lists (descending by donating time)

| Donated at       | Donator    | Amount   | Comments               |
| ---------------- |:---------:| --------:| ----------------------- |
|  2014-Jan-24 | Bernard Lim     | $20.00   |          |
|  2013-Dec-23 | William Kennedy     | $100.00   |          |
