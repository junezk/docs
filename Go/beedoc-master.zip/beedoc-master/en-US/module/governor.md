---
name: Governor module
sort: 7
---

## Governor module

Please [Admin module](./admin.md).