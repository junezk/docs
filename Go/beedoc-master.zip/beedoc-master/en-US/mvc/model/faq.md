---
name: FAQ
sort: 12
---

# FAQ

Q: My application need to support multiple database type. How can I check current database type when I am using Raw SQL?

A: You can check it by Ormer's [Driver method](orm.md#driver)
