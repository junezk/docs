---
name: Logging
sort: 11
---

# Logging

This part was removed in Beego 2.0, and please use [logs module](/zh-CN/module/logs.md)
