class ValidationError(Exception):
    pass

class UnavailableContentError(Exception):
    pass

class DatabaseProcessError(Exception):
    pass